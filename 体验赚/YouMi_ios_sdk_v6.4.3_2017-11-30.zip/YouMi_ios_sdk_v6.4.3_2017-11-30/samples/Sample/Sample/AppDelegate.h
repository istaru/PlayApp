//
//  AppDelegate.h
//  DouJinWallSample
//
//  Created by wangwei on 15-09-11.
//  Copyright (c) 2015年 wangwei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
