//
//  SourceADViewController.m
//  DouJinSample_MyO
//
//  Created by wangwei on 13-9-11.
//  Copyright (c) 2013年 DouJin Mobile Co. Ltd. All rights reserved.
//

#import "SourceADViewController.h"
#import "UIImageView+WebCache.h"
#import "UMWSourceData.h"

@interface SourceADViewController ()<UIAlertViewDelegate>
@property(nonatomic, retain) NSIndexPath* selectedIndex;
@end

@implementation SourceADViewController

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController.navigationBar setHidden:NO];
    [self.tableView reloadData];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
#pragma mark -
#pragma mark TableView
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}
-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *headerView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 50)] autorelease];
    headerView.backgroundColor = [UIColor grayColor];
    UILabel *headerLabel = [[[UILabel alloc] initWithFrame:headerView.bounds] autorelease];
    headerLabel.font = [UIFont systemFontOfSize:16];
    headerLabel.textColor = [[UIColor blackColor] colorWithAlphaComponent:0.5];
    headerLabel.textAlignment = NSTextAlignmentCenter;
    [headerView addSubview:headerLabel];
    switch (section) {
        case 0:
        {
            return nil;
        }
            break;
        case 1:
        {
            headerLabel.text = @"追加任务";
        }
            break;
            
        default:
            break;
    }
    return headerView;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    switch (section) {
        case 0:
            if (!self.apps) return 0;
            return [self.apps count];
            break;
        case 1:
            return [self.moreApps count];
            
        default:
            break;
    }
    
    return [self.apps count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellID = @"c";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellID];
    if (!cell) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellID] autorelease];
    }
    
    switch (indexPath.section) {
        case 0:
        {// 获得一个App的信息
            UMWSourceData *model = self.apps[indexPath.row];
            [cell.imageView setImageWithURL:[NSURL URLWithString:model.uMWIconURL] placeholderImage:[UIImage imageNamed:@"Icon.png"]];
            [cell.textLabel setText:[NSString stringWithFormat:@"%d分:%@", (int)model.uMWpoints, model.uMWname]];
            [cell.detailTextLabel setText:model.uMWadText];
        }
            break;
            
        case 1:
        {
            UMWSourceData *model = self.moreApps[indexPath.row];
            [cell.imageView setImageWithURL:[NSURL URLWithString:model.uMWIconURL] placeholderImage:[UIImage imageNamed:@"Icon.png"]];
            [cell.textLabel setText:[NSString stringWithFormat:@"%@",model.uMWname]];
            [cell.detailTextLabel setText:model.uMWadText];
        }
            break;
        default:
            break;
    }
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 50;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section ==0 ) {
        return 0;
    }
    return 50;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    self.selectedIndex = indexPath;
    
    switch (indexPath.section) {
        case 0:
        {
            //    // 安装一个APP
            UMWSourceData *mymodel = self.apps[self.selectedIndex.row];
            NSString *message = mymodel.uMWtaskBrief;
            message = [message stringByAppendingString:@"\n\n追加任务：\n"];
            for(NSDictionary *moreTask in mymodel.uMWMoreTasks){
                message = [message stringByAppendingString:[moreTask objectForKey:@"adtext"]];
                message = [message stringByAppendingString:@"\n"];
                message = [message stringByAppendingString:[NSString stringWithFormat:@"%@     ",[moreTask objectForKey:@"points"]]];
                int status = [[moreTask objectForKey:@"status"] intValue];
                if (status == 0) {
                    message = [message stringByAppendingString:@" [任务没到]"];
                }else if(status == 1){
                    message = [message stringByAppendingString:@" [任务进行中]"];
                }else{
                    message = [message stringByAppendingString:@" [任务过期]"];
                }
                message = [message stringByAppendingString:@"\n"];
                message = [message stringByAppendingString:@"\n"];
            }
            if(mymodel.uMWIsNeedReview){
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:mymodel.uMWname message:message delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"立即下载",@"提审", nil];
                [alertView show];
                [alertView release];
            }else{
                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:mymodel.uMWname message:message delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"立即下载", nil];
                [alertView show];
                [alertView release];
            }
        }
            break;
            
            
        case 1:
        {
            //    // 安装一个APP
            UMWSourceData *mymodel = self.moreApps[self.selectedIndex.row];
            NSString *message = @"";
            for(NSDictionary *moreTask in mymodel.uMWMoreTasks){
                message = [message stringByAppendingString:[moreTask objectForKey:@"adtext"]];
                message = [message stringByAppendingString:@"\n"];
                message = [message stringByAppendingString:[NSString stringWithFormat:@"%@     ",[moreTask objectForKey:@"points"]]];
                int status = [[moreTask objectForKey:@"status"] intValue];
                if (status == 0) {
                    message = [message stringByAppendingString:@" [任务没到]"];
                }else if(status == 1){
                    message = [message stringByAppendingString:@" [任务进行中]"];
                }else{
                    message = [message stringByAppendingString:@" [任务过期]"];
                }
                message = [message stringByAppendingString:@"\n"];
                message = [message stringByAppendingString:@"\n"];
            }
            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:mymodel.uMWname message:message delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"开始任务", nil];
            [alertView show];
            [alertView release];
        }
            break;
            
        default:
            break;
    }
}

#pragma mark -
#pragma mark uialertViewDelegate
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    switch (buttonIndex) {
        case 0:
            break;
            
        case 1:
        {
            if (self.selectedIndex.section == 0) {
                //安装一个APP
                UMWSourceData *mymodel = self.apps[self.selectedIndex.row];
                [UMWSourceData uMWinInstallSourceDataApp:mymodel douCallback:^(NSInteger code) {
                    if (code > 0) {
                        UIAlertView *alertview = [[UIAlertView alloc] initWithTitle:@"" message:@"开始任务出错" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
                        [alertview show];
                        [alertview release];
                    }
                }];
            }else{
                //深度任务
                UMWSourceData *mymodel = self.moreApps[self.selectedIndex.row];
                [UMWSourceData uMWBeginMoreTask:mymodel uMWinCallbackBlock:^(BOOL isSuccess){
                    if (isSuccess) {
                        UIAlertView *alertview = [[UIAlertView alloc] initWithTitle:@"" message:@"可以正常进行任务" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
                        [alertview show];
                        [alertview release];
                    }else{
                        UIAlertView *alertview = [[UIAlertView alloc] initWithTitle:@"" message:@"应用没安装" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
                        [alertview show];
                        [alertview release];
                    }
                }];
            }
        }
            break;
            
        case 2:
        {
            //提审
            UMWSourceData *mymodel = self.apps[self.selectedIndex.row];
            
            /*
             status:0  提审成功，等待审核给分
             status:402 还没开始任务
             status:404 还没完成
             */
            [UMWSourceData uMWReview:mymodel uMWinCallbackBlock:^(NSInteger status){
                NSString *statusString = @"";
                switch (status) {
                    case 0:
                        statusString = @"提审成功，等待审核奖励";
                        break;
                        
                    case 402:
                        statusString = @"还没开始体验";
                        break;
                        
                    case 404:
                        statusString = @"任务还没完成，请回去继续体验";
                        break;
                        
                        
                    default:
                        break;
                }
                UIAlertView *alertview = [[UIAlertView alloc] initWithTitle:@"" message:statusString delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
                [alertview show];
                [alertview release];
            }];
        }
            break;
        default:
            break;
    }
}
@end
