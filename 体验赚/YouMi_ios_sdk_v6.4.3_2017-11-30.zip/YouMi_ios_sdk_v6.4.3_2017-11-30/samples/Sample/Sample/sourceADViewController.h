//
//  SourceADViewController.h
//  DouJinSample_MyO
//
//  Created by wangwei on 15-9-11.
//  Copyright (c) 2015年 DouJin Mobile Co. Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SourceADViewController : UITableViewController
@property (nonatomic,retain) NSArray *apps;
@property (nonatomic,retain) NSArray *moreApps;
@end
