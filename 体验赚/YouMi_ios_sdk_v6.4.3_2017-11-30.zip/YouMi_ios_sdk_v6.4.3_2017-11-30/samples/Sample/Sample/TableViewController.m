//
//  TableViewController.m
//  DouJinSample
//
//  Created by wangwei on 15/12/11.
//  Copyright © 2015年 wangwei. All rights reserved.
//

#import "TableViewController.h"
#import "sourceADViewController.h"
#import "UMWSourceData.h"
#import "UMWSDK.h"

@interface TableViewController()
@property (retain, nonatomic) SourceADViewController *tableviewController;
@end

@implementation TableViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    // Do any additional setup after loading the view from its nib.
    self.tableviewController = [[SourceADViewController alloc]initWithNibName:@"sourceADViewController" bundle:nil];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)buttonCheckPointPressed:(id)sender {
    [UMWSDK UMWCheckPointsWithCallbackBlock:^(NSArray *PointInfo) {
        NSString *message = [NSString stringWithFormat:@"查询积分返回的信息 %@",PointInfo];
        UIAlertView *alertview = [[UIAlertView alloc] initWithTitle:@"" message:message delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil];
        [alertview show];
        [alertview release];
    }];
}

- (void)showSourcePressed:(id)sender {
    [self.navigationController pushViewController:_tableviewController animated:YES];
    [UMWSourceData uMWinRequestSourceData:1 countPerPage:100 uMWinCallbackBlock:^(NSArray *theApps,NSArray *moreApps, NSError *error) {
        // theApps 是 UMWSourceData 的对象列表
        if (!error) {
            _tableviewController.apps = theApps;
            _tableviewController.moreApps = moreApps;
            [_tableviewController.tableView reloadData];
        }
    }];
}

- (void)buttonShowPressed:(id)sender {
    
    
    UIViewController *viewController = [UMWSDK UMWGetViewController:^{
        NSLog(@"积分墙打开");
    } UMWinDidDismissBlock:^(UIViewController *viewController){
        NSLog(@"积分墙关闭");
        [viewController dismissViewControllerAnimated:YES completion:nil];
    }];
    [self presentViewController:viewController animated:YES completion:nil];
}


#pragma mark - tableViewDelegate
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section == 0) {
        return 2;
    }
    
    return 4;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 50;
}

-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 30;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, 30)];
    label.backgroundColor = [UIColor colorWithRed:0.52 green:0.65 blue:0.23 alpha:1.0];
    if (section == 0) {
        label.text = @"展示积分墙";
    }else{
        label.text = @"积分管理";
    }
    return label;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"不重用"];
    NSInteger index = indexPath.row + indexPath.section*2;
    switch (index) {
        case 0:
            cell.textLabel.text = @"展示积分墙";
            break;
        case 1:
            cell.textLabel.text = @"展示源数据积分墙";
            break;
        case 2:
            cell.textLabel.text = @"查询积分";
            break;
        case 3:
            break;
        case 4:
            break;
        case 5:
            break;
            
        default:
            break;
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    NSInteger index = indexPath.row + indexPath.section*2;
    
    switch (index) {
        case 0:
            [self buttonShowPressed:nil];
            break;
            
        case 1:
            [self showSourcePressed:nil];
            break;
            
        case 2:
            [self buttonCheckPointPressed:nil];
            break;
            
        case 3:
            break;
        case 4:
            break;
        case 5:
            break;
            
        default:
            break;
    }
}

@end
