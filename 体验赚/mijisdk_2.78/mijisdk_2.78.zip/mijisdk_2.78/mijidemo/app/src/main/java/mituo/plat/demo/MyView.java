package mituo.plat.demo;


import mituo.plat.lib.MituoAppListActivity;

public class MyView extends MituoAppListActivity{

}
